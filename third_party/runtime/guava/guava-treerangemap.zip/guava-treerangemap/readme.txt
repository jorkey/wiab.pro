Project name: guava-treerangemap
Creation date: 07.02.2014
Author: dyukon@gmail.com (Denis Konovalchik)
Build tool: ant

The project is created as walkaround
for lack of support TreeRangeMap class in Guava 16.0.1 package.

The project contains following directories and files:
  /lib - libraries necessary for the build
    /guava - Guava library
    /jsr305 - JavaX library
  /nbproject - directory with project for NetBeans
  /src - Java source files
    /com/google/common/collect
      GwtAbstractMap - replace for abstract class java.util.AbstractMap
      GwtNavigableMap.java - replace for interface java.util.NavigableMap
      GwtNavigableSet.java - replace for interface java.util.NavigableSet
      GwtRangeMap.java - replace for interface com.google.common.collect.RangeMap
      GwtTreeMap.java - replace for class java.util.TreeMap
      GwtTreeRangeMap.java - replace for class com.google.common.collect.TreeRangeMap
  build.properties - properties for ant building
  build.xml

Usage:
1) Copy guava-16.0.1.jar into /lib/guava directory
2) Copy jsr305.jar into /lib/jsr305 directory
3) Run ant from the project root directory

After successful build two jar's are created in /build/jar directory:
  guava-treerangemap-16.0.1.jar (containing Java classes)
  guava-treerangemap-gwt-16.0.1.jar (containing Java source for GWT)
The jar's should be put into thirdparty/runtime/guava directory of Wiab project.

The project should be removed from Wiab when TreeRangeMap class
will be completely supported in Guava.
